 Dieses Archiv enth�lt den multifunktionalen integrierten Archivmanager WinRAR:

   Funktionen von WinRAR:

 - WinRAR arbeitet mit einem speziellen Kompressionsalgorithmus.
   Damit sind hohe Kompressionsraten m�glich, insbesondere bei
   ausf�hrbaren Dateien, Objekt-Bibliotheken, gro�en Textdateien, usw.

 - WinRAR bietet einen optionalen Kompressionsalgorithmus, der
   speziell f�r Multimedia-Daten optimiert ist.

 - WinRAR unterst�tzt Dateien und Archive bis zu einer Gr��e von 
   9.223.372.036.854.775.807 Byte, das sind ungef�hr 9000 PB. 
   Die Anzahl der Dateien ist praktisch unbegrenzt.

 - WinRAR enth�lt vollst�ndige Unterst�tzung f�r RAR- und
   ZIP 2.0-Archive und ist in der Lage, CAB, ARJ, LZH, TAR,
   GZ, ACE, UUE, BZ2, JAR, ISO, Z und 7Z-Archive zu entpacken.

 - WinRAR unterst�tzt NTFS-Dateisicherheit und NTFS-Datenstr�me.

 - WinRAR bietet sowohl eine interaktive grafische Windows-
   Benutzeroberfl�che als auch die Bedienung �ber die
   Kommandozeile.

 - Mit WinRAR k�nnen "solide" Archive erstellt werden, wodurch die 
   Kompressionsrate um 10% - 50% im Vergleich zu herk�mmlichen 
   Methoden gesteigert werden kann, besonders wenn eine gro�e 
   Anzahl kleiner Dateien gepackt wird.

 - WinRAR erlaubt das Erstellen und �ndern von SFX-Archiven unter
   Verwendung des Standard-SFX-Moduls oder externen SFX-Modulen.

 - Mit WinRAR k�nnen mehrteilige Archive auch selbstentpackend 
   erstellt werden.

 - WinRAR bietet eine Reihe von Servicefunktionen, wie Passwortabfrage
   oder die M�glichkeit, Kommentare zum Archiv oder zu Dateien zu
   speichern. Physikalisch besch�digte Archive k�nnen repariert und
   Archive k�nnen gegen Ver�nderung gesch�tzt ("verschlossen") 
   werden. 
